# 2021-ProjetReprise-ChampolJulien

Projet labyrinthe - version live

Objectifs réalisés :

- [X] Objectif 1 : dessiner un labyrinthe

    - [X] Exercice 1 06/09
    - [X] Exercice 2 07/09
    - [X] Exercice 3 07/09
    - [X] Exercice 4 07/09
    - [X] Exercice 5 07/09
  <br/>

- [X] Objectif 2 : tests (tests unitaires sur les formats de fichiers)
  
    - [X] Exercice 6 08/09
    - [X] Exercice 7 08/09
    - [X] Exercice 8 08/09
    - [X] Exercice 9 08/09
  <br/> 

- [X] Objectif 3 : déplacer des personnages
  
    - [X] Exercice 10 08/09
    - [X] Exercice 11 08/09
    - [X] Exercice 12 08/09
    - [X] Exercice 13 08/09
    - [X] Exercice 14 10/09
    - [X] Exercice 15 13/09
  <br/>

- [X] Objectif 4 : monstres (polymorphisme sur les personnages)
  
  - [X] Exercice 16 13/09
  - [X] Exercice 17 14/09
  - [X] Exercice 18 15/09 
  <br/>

- [X] Objectif 5 : améliorations simples (animations, éclairage localisé)
  
  - [X] Exercice 19 16/09
  - [X] Exercice 20 17/09  
  <br/>

- [ ] Objectif 6 : améliorations plus complexe basées sur les plus courts chemins

    - [ ] Exercice 21
    - [ ] Exercice 22
    - [ ] Exercice 23
    - [ ] Exercice 24
    - [ ] Exercice 25
    - [ ] Exercice 26
    - [ ] Exercice 27
    - [ ] Exercice 28
    - [ ] Exercice 29   
  